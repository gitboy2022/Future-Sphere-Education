let browser = prompt("What is your browser name?");
if (browser === "Edge") {
    alert("You got the Edge browser!");
} else if (browser==="Chrome" || browser==="Firefox" || browser==="Safari" || browser === "Opera") {
    alert("The Opera browser is also supported!");
}
else {
    alert("We hope that this page looks ok!");
}
class AddNumbers
{
    public static void main(String args[])
    {
      int a = 20;
      int b = 40;

      System.out.println(add(a, b));
    }
    
    public static int add(int a, int b){
      return a + b;
    }
}

class Main {
  public static void main(String[] args) {
    AddNumbers.main(args);
  }
}

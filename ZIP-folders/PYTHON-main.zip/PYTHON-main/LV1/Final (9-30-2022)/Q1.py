import turtle
import time
j = turtle.Turtle()
j.speed(0)
r = 50

for i in range(4):
  j.circle(r)
  j.lt(90)

time.sleep(11)

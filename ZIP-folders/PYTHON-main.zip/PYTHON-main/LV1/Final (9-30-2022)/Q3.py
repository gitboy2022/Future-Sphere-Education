import time

for i in range(101):
  if i == 25:
    print("First")
  elif i == 50:
    print("Second")
  elif i == 75:
    print("Third")
  elif i == 100:
    print("Fourth")
  else:
    print(i)

time.sleep(11)

import turtle
import time
l1 = 0

t = turtle.Turtle()

while l1 <= 8: 
  t.fd(100)
  t.rt(45)
  l1 = l1 + 1

time.sleep(1)
# PART_1

x = 10
y = 20
if x >= y:
    print("X is bigger")

# PART_2
secret = 7
guess = int(input("Guess a number between 0 and 10!"))
if guess == secret:
    print("You got the number right! It was 7")

# DONE

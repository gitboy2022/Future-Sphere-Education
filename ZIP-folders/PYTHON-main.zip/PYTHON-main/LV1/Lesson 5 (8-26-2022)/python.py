grade = int(input("What is your grade? Enter a number from 0 ~ 100"))
if grade <= 59:
    print("Your final grade is F")
elif grade <= 69:
    print("Your final grade is D")
elif grade <= 79:
    print("Your final grade is C")
elif grade <= 89:
    print("Your final grade is B")
elif grade <= 100:
    print("Your final grade is A")

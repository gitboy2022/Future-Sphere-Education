import time

x = 3
y = -7
z = 2

result = x * y * z

if result > 0:
    print("positive sign")
elif result < 0:
    print("negative sign")
else:
    print("neither")

time.sleep(1)

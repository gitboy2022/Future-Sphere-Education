import turtle as tt
import time as t
tt.speed(0)

for i in range(36):
    for ii in range(5):
        tt.fd(100)
        tt.rt(144)
    tt.rt(10)

for i in range(10000):
    print(i + 1)

t.sleep(2)

numbers = [4, 6, 8, 24, 12, 2]

# find the maximum number
max_number = max(numbers)
print(max_number)
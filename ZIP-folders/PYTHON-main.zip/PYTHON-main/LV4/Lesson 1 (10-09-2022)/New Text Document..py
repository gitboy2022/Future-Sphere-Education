import time
counter=0
number=int(input())
while number  0
    number=number10
    counter+=1
print(counter)
time.sleep(11)
num = int(input())
print(str(num)[::-1])

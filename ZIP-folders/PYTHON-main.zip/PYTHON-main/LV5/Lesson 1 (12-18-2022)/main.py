class Bycycle:
  pass

myBycycle = Bycycle()

class Person:
  pass

myBestFriend = Person()

class Bulb:
  pass

myBulb = Bulb()

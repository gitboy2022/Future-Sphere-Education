#HW#19

#Remember, you get 80% for submitting your
#classwork before the session ends.
#See below to see the requirements for getting +10% and +20%

#NOTE: This is due at 12AM EST of the next time / day we meet!!!
#NOTE2: Please submit your USACO / Codeforces answer to the website 
#If it does not pass ALL test cases, your answer will be considered
#INCORRECT!!!


#Requirements to get +10% :
#  Correctly answer AT LEAST 2 questions for #1.  Leetcode Questions

#Requirements to get +20% :
#  Correctly answer ALL questions for #1.  Leetcode Questions (There are 3 Questions)
#  Correctly answer #2.  USACO - Cow Gymnastics


#1.  Leetcode Questions

#Solve the following Leetcode Questions
#as was given in the instructions from HW#9 / HW#10


#a.  Find the Number of Good Pairs I

# https://leetcode.com/problems/find-the-number-of-good-pairs-i/description/

###COPY / PASTE Find the Number of Good Pairs I


###END Find the Number of Good Pairs I




#b.  Find the Integer Added to Array I

# https://leetcode.com/problems/find-the-integer-added-to-array-i/description/

###COPY / PASTE Find the Integer Added to Array I


###END Find the Integer Added to Array I





#c.  Distribute Elements Into Two Arrays I

# https://leetcode.com/problems/distribute-elements-into-two-arrays-i/description/

###COPY / PASTE Distribute Elements Into Two Arrays I


###END Distribute Elements Into Two Arrays I









#2.  USACO - Cow Gymnastics

#Please answer the following USACO question below.

#MAKE SURE TO SUBMIT YOUR FILE / SOLUTION to USACO
#AND CHECK IT WORKS COMPLETELY!

#IF IT DOESN'T WORK COMPLETELY (AS IN PASSES ALL TEST CASES)
#YOU DO NOT RECEIVE CREDIT FOR THIS PROBLEM!!!

#GOOD LUCK!

# https://usaco.org/index.php?page=dec19results
